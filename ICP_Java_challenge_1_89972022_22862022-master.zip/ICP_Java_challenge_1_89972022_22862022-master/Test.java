public class Test{
  public static void main(String[] args){
     Item p = new Item();
    p.capture();
    p.read();
  }
}