import java.io.*;
import java.util.*;
public class Item{
  //instance variables setters getters
  //scanner class , read and set
  private String name;
  private int quantity;
  private float price;
  
  public Item(){}
  public Item(String name,int quantity, float price){
  //Inside our constructor the item is created with it's characteristics(name,price and quantity).
    
  this.name=name;
  this.quantity=quantity;
  this.price=price;
  }
  
  public String getName(){return name;}
  
  public int getQuantity(){return quantity;}
  
  public float getPrice(){return price;}
  
  public void setName(String name){this.name=name;}
  
  public void setQuantity(int quantity){this.quantity=quantity;}
  
  public void setPrice(float price){this.price=price;}
  // These are the setter and getter methods for the instance variables
  
  public void capture(){
    for(int i=0; i <10 ; i++){
      Scanner input= new Scanner(System.in);
      String itemname = input.next();
      int quant = input.nextInt();
      float price=input.nextFloat();
      Item item = new Item(itemname,quant,price);
      write(itemname); // storing  each item in a file
      write(" ");
      String squant= quant+"";
      write(squant);
      write(" ");
      String sprice = price +"";
      write(sprice);
      write("\n");
      
    }
  
  
  }
  
  //It writes the items into a file
  public void write(String s){
     try{
            FileWriter fw = new FileWriter("essentials_stock.txt",true); //creating a new filewriter object that allows for addition of information into the file
            fw.write(s);
            fw.close();
            FileWriter file = new FileWriter("backup_essentials_stock.txt",true); //creating a new filewriter object that allows for addition of information into the file
            file.write(s);
            file.close();
     } // after we write into the file it has to be closed for saving.
        catch(IOException e){ // catching the error whenever a user enters a filename which does not exist.
            System.out.println("File does not exist");
        }
  
  }
  
  //it reads and re-constructs the items from the text file
  public void read(){
    try {
            String path = System.getProperty("user.dir");
            String name = "essentials_stock.txt";
            File file = new File(path+"//"+name);// construction of  a file object, given a particular item, that stores information of that item.
            Scanner sc = new Scanner(file); // construction of a scanner class to read the from the file.

            while (sc.hasNextLine()) {// if the file still has a next line. The loop will stop when we reach the end of the list of items.
                String x = sc.nextLine();
                String[] y = x.split(" ");// information on each line is split by space
                String itemname = y[0];
                String amount = y[1];
                int quant=Integer.parseInt(amount);
                float price=Float.valueOf(y[2]);
                Item item = new Item(itemname,quant,price); // each line holds an information of an item in stock
                System.out.print(itemname+" "+ quant + " " + "Ghc"+ price+"\n");
            }}

        catch (FileNotFoundException e){System.out.println("File does not exist");}
  
  }
}